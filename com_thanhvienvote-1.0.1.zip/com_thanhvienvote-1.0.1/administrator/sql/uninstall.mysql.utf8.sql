DROP TABLE IF EXISTS `#__thanhvienvote_vote`;
